<?php
require_once 'includes/init.php';

requireAdmin();

// Total Tickets
$total_tickets = $pdo->query("SELECT COUNT(*) FROM tickets")->fetchColumn();
$open_tickets = $pdo->query("SELECT COUNT(*) FROM tickets WHERE status NOT IN ('Repaired', 'Canceled', 'RMA', 'Shipped')")->fetchColumn();
$completed_tickets = $pdo->query("SELECT COUNT(*) FROM tickets WHERE status IN ('Repaired', 'Shipped')")->fetchColumn();
$customers_count = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();

// Tickets by Status
$sql = "SELECT status, COUNT(*) as count FROM tickets GROUP BY status";
$stmt = $pdo->query($sql);
$status_counts = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Tickets by Brand
$brand_sql = "SELECT brand, COUNT(*) as count FROM tickets GROUP BY brand ORDER BY count DESC";
$brand_counts = $pdo->query($brand_sql)->fetchAll(PDO::FETCH_KEY_PAIR);

$all_statuses = [
    'Waiting to Arrive',
    'Under Repair',
    'Waiting for Parts',
    'Repaired',
    'Canceled',
    'Shipped',
    'RMA'
];

include 'includes/nav.php';
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo t('Overview'); ?></h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="all_tickets.php" class="btn btn-sm btn-outline-primary"><?php echo t('Manage Tickets'); ?></a>
    </div>
</div>

<!-- Key Metrics -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title"><?php echo t('Total Tickets'); ?></h5>
                <h2 class="display-4 fw-bold"><?php echo $total_tickets; ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title"><?php echo t('Open Repairs'); ?></h5>
                <h2 class="display-4 fw-bold"><?php echo $open_tickets; ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title"><?php echo t('Repaired'); ?></h5>
                <h2 class="display-4 fw-bold"><?php echo $completed_tickets; ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title"><?php echo t('Customers'); ?></h5>
                <h2 class="display-4 fw-bold"><?php echo $customers_count; ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Status Breakdown -->
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header">
                <h5 class="mb-0"><?php echo t('Ticket Status Breakdown'); ?></h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <?php foreach ($all_statuses as $status): ?>
                        <?php $count = $status_counts[$status] ?? 0; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?php echo t($status); ?>
                            <span class="badge bg-secondary rounded-pill"><?php echo $count; ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <!-- Brands Breakdown -->
    <div class="col-md-6 mb-4">
        <div class="card shadow-sm h-100">
            <div class="card-header">
                <h5 class="mb-0"><?php echo t('Top Brands'); ?></h5>
            </div>
            <div class="card-body">
                <?php if (count($brand_counts) > 0): ?>
                    <ul class="list-group list-group-flush">
                        <?php foreach ($brand_counts as $brand => $count): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo htmlspecialchars($brand ?: 'Unknown'); ?>
                                <span class="badge bg-primary rounded-pill"><?php echo $count; ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p class="text-muted text-center mt-3"><?php echo t('No data available.'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>