<?php
require_once __DIR__ . '/init.php';
// Load Settings
if (file_exists('config/settings.php')) {
    include 'config/settings.php';
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo defined('COMPANY_NAME') ? COMPANY_NAME : 'ConsoleFix.dk'; ?> - Repair System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts: Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/css/style.css"> <!-- Custom CSS if needed -->
    <link rel="icon" type="image/png" href="<?php echo BASE_URL; ?>/images/logo.png">
    <script>
        // Prevent FOUC by setting theme immediately
        (function () {
            const storedTheme = localStorage.getItem('theme');
            const preferredTheme = storedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
            document.documentElement.setAttribute('data-bs-theme', preferredTheme);
        })();
    </script>
</head>

<body>

    <?php
    $current_page = basename($_SERVER['PHP_SELF']);
    ?>

    <!-- Sidebar -->
    <div class="sidebar" id="mySidebar">
        <div class="sidebar-header d-flex flex-column align-items-center">
            <img src="<?php echo BASE_URL; ?>/images/logo.png" alt="Logo" class="img-fluid mb-2"
                style="max-height: 80px; border-radius: 10px;">
        </div>

        <?php if (isset($_SESSION['user_id'])): ?>
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="<?php echo BASE_URL; ?>/overview.php"
                    class="<?php echo $current_page == 'overview.php' ? 'nav-active' : ''; ?>">
                    <i class="fas fa-tachometer-alt me-2"></i> <?php echo t('Overview'); ?>
                </a>
                <a href="<?php echo BASE_URL; ?>/all_tickets.php"
                    class="<?php echo $current_page == 'all_tickets.php' ? 'nav-active' : ''; ?>">
                    <i class="fas fa-ticket-alt me-2"></i> <?php echo t('Manage Tickets'); ?>
                </a>
                <a href="<?php echo BASE_URL; ?>/devices.php"
                    class="<?php echo $current_page == 'devices.php' ? 'nav-active' : ''; ?>">
                    <i class="fas fa-laptop me-2"></i> <?php echo t('Devices'); ?>
                </a>
                <a href="<?php echo BASE_URL; ?>/customers.php"
                    class="<?php echo $current_page == 'customers.php' ? 'nav-active' : ''; ?>">
                    <i class="fas fa-users me-2"></i> <?php echo t('Customers'); ?>
                </a>
                <a href="<?php echo BASE_URL; ?>/languages.php"
                    class="<?php echo $current_page == 'languages.php' ? 'nav-active' : ''; ?>">
                    <i class="fas fa-language me-2"></i> <?php echo t('Languages'); ?>
                </a>
                <a href="<?php echo BASE_URL; ?>/create_ticket.php"
                    class="<?php echo $current_page == 'create_ticket.php' ? 'nav-active' : ''; ?>">
                    <i class="fas fa-plus-circle me-2"></i> <?php echo t('New Ticket'); ?>
                </a>
                <a href="<?php echo BASE_URL; ?>/create_customer.php"
                    class="<?php echo $current_page == 'create_customer.php' ? 'nav-active' : ''; ?>">
                    <i class="fas fa-user-plus me-2"></i> <?php echo t('New Customer'); ?>
                </a>
            <?php else: ?>
                <a href="<?php echo BASE_URL; ?>/my_tickets.php"
                    class="<?php echo $current_page == 'my_tickets.php' ? 'nav-active' : ''; ?>">
                    <i class="fas fa-list me-2"></i> <?php echo t('My Tickets'); ?>
                </a>
                <a href="<?php echo BASE_URL; ?>/create_ticket.php"
                    class="<?php echo $current_page == 'create_ticket.php' ? 'nav-active' : ''; ?>">
                    <i class="fas fa-plus-circle me-2"></i> <?php echo t('Open New Ticket'); ?>
                </a>
            <?php endif; ?>

            <a href="<?php echo BASE_URL; ?>/profile.php"
                class="mt-auto <?php echo $current_page == 'profile.php' ? 'nav-active' : ''; ?>">
                <i class="fas fa-user me-2"></i> <?php echo t('Profile'); ?>
            </a>

            <!-- Theme Toggle Switch -->
            <div class="px-4 py-3 border-top border-secondary">
                <div class="form-check form-switch d-flex justify-content-between align-items-center ps-0">
                    <label class="form-check-label text-light small mb-0" for="themeSwitch">
                        <i class="fas fa-sun me-1"></i> / <i class="fas fa-moon ms-1"></i>
                    </label>
                    <input class="form-check-input ms-2" type="checkbox" id="themeSwitch" style="cursor: pointer;">
                </div>
            </div>

            <a href="<?php echo BASE_URL; ?>/logout.php" class="text-danger mb-4">
                <i class="fas fa-sign-out-alt me-2"></i> <?php echo t('Logout'); ?>
            </a>
        <?php else: ?>
            <a href="<?php echo BASE_URL; ?>/login.php"
                class="mt-auto <?php echo $current_page == 'login.php' ? 'nav-active' : ''; ?>">
                <i class="fas fa-sign-in-alt me-2"></i> <?php echo t('Login'); ?>
            </a>
        <?php endif; ?>
    </div>

    <!-- Main Content -->
    <div class="main-content" id="main">
        <button class="btn btn-dark mobile-nav-toggle" onclick="toggleSidebar()">☰ <?php echo t('Menu'); ?></button>