<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

// Secure Session Start
secureSessionStart();

// Define Base URL for absolute pathing
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];

// Determine paths with normalized slashes
$doc_root = str_replace('\\', '/', dirname(__DIR__)); // Physical path to root (parent of includes)
$script_dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_FILENAME'])); // Physical path of current script
$script_url_dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])); // URL path of current script

// Calculate subdirectory relative to root
$subdir = str_replace($doc_root, '', $script_dir);

// Strip subdirectory from URL path to get Base URL path
if ($subdir) {
    $subdir = str_replace('\\', '/', $subdir);
    $len = strlen($subdir);
    if (substr($script_url_dir, -$len) === $subdir) {
        $script_url_dir = substr($script_url_dir, 0, -$len);
    }
}

define('BASE_URL', $protocol . '://' . $host . rtrim($script_url_dir, '/'));

// Initialize Translations
$translations = load_translations();

// Handle Language Switch (GET request)
if (isset($_GET['lang'])) {
    $lang = preg_replace('/[^a-zA-Z]/', '', $_GET['lang']); // Sanitize
    // Check if lang exists in DB
    $stmt = $pdo->prepare("SELECT id FROM languages WHERE code = ? AND is_active = 1");
    $stmt->execute([$lang]);
    if ($stmt->fetch()) {
        $_SESSION['lang'] = $lang;
    }
    // Redirect to remove query param
    $redirect = strtok($_SERVER["REQUEST_URI"], '?');
    if (!empty($_SERVER['QUERY_STRING'])) {
        $query = $_SERVER['QUERY_STRING'];
        $query = preg_replace('/(&?)lang=[^&]*/', '', $query);
        if ($query) {
            $redirect .= '?' . $query;
        }
    }
    header("Location: " . $redirect);
    exit;
}
?>