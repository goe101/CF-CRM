<?php
/**
 * Check if a user is logged in.
 *
 * @return bool True if user_id is set in session.
 */
function isLoggedIn()
{
    return isset($_SESSION['user_id']);
}

/**
 * Check if the currently logged-in user is an admin.
 *
 * @return bool True if role is 'admin'.
 */
function isAdmin()
{
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

/**
 * Enforce login requirement. Redirects to login.php if not logged in.
 *
 * @return void
 */
function requireLogin()
{
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit;
    }
}

/**
 * Enforce admin requirement. Redirects to login or my_tickets.php depending on state.
 *
 * @return void
 */
function requireAdmin()
{
    requireLogin();
    if (!isAdmin()) {
        header("Location: my_tickets.php"); // Redirect non-admins
        exit;
    }
}

/**
 * Get a specific Bootstrap badge HTML for a given ticket status.
 *
 * @param string $status The status string (e.g., 'Repaired').
 * @return string HTML span element with badge classes.
 */
function getStatusBadge($status)
{
    $colors = [
        'Waiting to arrive' => 'secondary',
        'Under Repair' => 'info',
        'Waiting for parts' => 'warning',
        'Repaired' => 'success',
        'Canceled' => 'danger',
        'Shipped' => 'primary',
        'RMA' => 'dark'
    ];
    $color = $colors[$status] ?? 'secondary';
    return "<span class='badge bg-$color'>$status</span>";
}

// --------------------------------------------------------------------------
// Security Helpers
// --------------------------------------------------------------------------

/**
 * Start a secure session with strictly defined cookie parameters.
 * Should be called in includes/init.php.
 *
 * @return void
 */
function secureSessionStart()
{
    if (session_status() === PHP_SESSION_NONE) {
        // Set secure session cookie params
        session_set_cookie_params([
            'lifetime' => 0, // Session cookie
            'path' => '/',
            'domain' => '', // Current domain
            'secure' => isset($_SERVER['HTTPS']), // True if HTTPS
            'httponly' => true, // JavaScript cannot access session cookie
            'samesite' => 'Strict' // Protects against CSRF
        ]);
        session_start();
    }
}

/**
 * Generate a cryptographically secure CSRF token.
 *
 * @return string The generated or existing token.
 */
function generateCsrfToken()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify the provided CSRF token against the session token.
 * Terminates execution if validation fails.
 *
 * @param string $token The token from the form (POST/GET).
 * @return bool True on success.
 */
function verifyCsrfToken($token)
{
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        die("CSRF Validation Failed. Please refresh the page.");
    }
    return true;
}

/**
 * Generate a hidden input field for CSRF protection.
 *
 * @return string HTML input element.
 */
function csrfInput()
{
    $token = generateCsrfToken();
    return '<input type="hidden" name="csrf_token" value="' . $token . '">';
}

/**
 * Escape string for safe HTML output (XSS Protection).
 *
 * @param string $string The raw string.
 * @return string The escaped string.
 */
function e($string)
{
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// --------------------------------------------------------------------------
// Language & Translation Helpers
// --------------------------------------------------------------------------

/**
 * Get the current language code.
 *
 * @return string
 */
function get_current_language()
{
    if (isset($_SESSION['lang'])) {
        return $_SESSION['lang'];
    }

    // Fetch default from DB
    global $pdo;
    if (isset($pdo)) {
        try {
            $stmt = $pdo->query("SELECT code FROM languages WHERE is_default = 1 LIMIT 1");
            $default = $stmt->fetchColumn();
            if ($default) {
                return $default;
            }
        } catch (PDOException $e) {
            // Ignore if DB not ready
        }
    }

    return 'en';
}

/**
 * Set the default language for the system.
 *
 * @param int $id The language ID.
 * @return bool True on success.
 */
function set_default_language($id)
{
    global $pdo;
    try {
        $pdo->beginTransaction();
        // Reset all to 0
        $pdo->exec("UPDATE languages SET is_default = 0");
        // Set new default
        $stmt = $pdo->prepare("UPDATE languages SET is_default = 1 WHERE id = ?");
        $stmt->execute([$id]);
        $pdo->commit();
        return true;
    } catch (PDOException $e) {
        $pdo->rollBack();
        return false;
    }
}

/**
 * Load all translations for the current language.
 *
 * @return array
 */
function load_translations()
{
    global $pdo;

    $langCode = get_current_language();
    $langId = 1; // Default to English ID usually 1

    // Get language ID from code
    try {
        if (!isset($pdo)) {
            // Fallback if $pdo isn't global yet?
            return [];
        }
        $stmt = $pdo->prepare("SELECT id FROM languages WHERE code = ? LIMIT 1");
        $stmt->execute([$langCode]);
        $lang = $stmt->fetch();
        if ($lang) {
            $langId = $lang['id'];
        }
    } catch (PDOException $e) {
        // Table might not exist yet during install
        return [];
    }

    // Fetch translations
    $translations = [];
    try {
        $stmt = $pdo->prepare("SELECT translation_key, translation_value FROM translations WHERE language_id = ?");
        $stmt->execute([$langId]);
        while ($row = $stmt->fetch()) {
            $translations[$row['translation_key']] = $row['translation_value'];
        }
    } catch (PDOException $e) {
        return [];
    }

    return $translations;
}

/**
 * Translate a string.
 *
 * @param string $key The key to translate (usually the English text).
 * @param string $default Optional default value (if not provided, uses key).
 * @return string The translated string.
 */
function t($key, $default = null)
{
    global $translations;

    if (isset($translations[$key]) && !empty($translations[$key])) {
        return $translations[$key];
    }

    return $default !== null ? $default : $key;
}
?>