</div> <!-- End Main Content -->

<footer class="text-center mt-5 py-4 text-muted border-top">
    <p>&copy; <?php echo date('Y'); ?> <?php echo defined('COMPANY_NAME') ? COMPANY_NAME : 'ConsoleFix.dk'; ?>.
        <?php echo t('All rights reserved.'); ?>
    </p>
</footer>

<!-- Custom JS -->
<!-- Custom JS -->
<script src="<?php echo BASE_URL; ?>/js/script.js"></script>
<script src="<?php echo BASE_URL; ?>/js/theme.js"></script>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>