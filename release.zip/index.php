<?php
include 'includes/nav.php';
?>

<div class="p-5 mb-4 bg-light rounded-3 shadow-sm">
    <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold"><?php echo defined('COMPANY_NAME') ? COMPANY_NAME : 'ConsoleFix.dk'; ?> - Repair Services</h1>
        <p class="col-md-8 fs-4">
            <?php echo t('Specializing in Laptop Motherboard and Gaming Consoles Repairs.'); ?></p>
        <?php if (!isset($_SESSION['user_id'])): ?>
            <a href="login.php" class="btn btn-primary btn-lg" type="button"><?php echo t('Login to Start'); ?></a>
        <?php else: ?>
            <a href="<?php echo $_SESSION['role'] === 'admin' ? 'overview.php' : 'my_tickets.php'; ?>"
                class="btn btn-success btn-lg" type="button"><?php echo t('Go to Dashboard'); ?></a>
        <?php endif; ?>
    </div>
</div>

<div class="row align-items-md-stretch">
    <div class="col-md-6 mb-4">
        <div class="h-100 p-5 text-white bg-dark rounded-3">
            <h2><?php echo t('Expert Technicians'); ?></h2>
            <p><?php echo t('We handle complex motherboard repairs for Apple, Sony, Microsoft, and more.'); ?>
            </p>
        </div>
    </div>
    <div class="col-md-6 mb-4">
        <div class="h-100 p-5 bg-light border rounded-3">
            <h2><?php echo t('Track Your Repairs'); ?></h2>
            <p><?php echo t('Log in to view the real-time status of your device. We provide detailed updates from receipt to repair.'); ?></p>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>