<?php
require_once 'includes/init.php';

requireAdmin();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token']);
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $cvr = trim($_POST['cvr']);
    $password = $_POST['password'];
    $notes = trim($_POST['notes']);

    if ($name && $email && $password) {
        // Check if email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email already exists.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, address, cvr, password, role, notes) VALUES (?, ?, ?, ?,
?, ?, 'customer', ?)");
            if ($stmt->execute([$name, $email, $phone, $address, $cvr, $hashed_password, $notes])) {
                $message = "Customer created successfully!";
            } else {
                $error = "Error creating customer.";
            }
        }
    } else {
        $error = "Name, Email, and Password are required.";
    }
}

include 'includes/nav.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-success text-white">
                <h4 class="mb-0"><?php echo t('Create New Customer'); ?></h4>
            </div>
            <div class="card-body">
                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars(t($message)); ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars(t($error)); ?></div>
                <?php endif; ?>

                <form method="POST">
                    <?php echo csrfInput(); ?>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label"><?php echo t('Full Name'); ?> *</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><?php echo t('Email Address'); ?> *</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label"><?php echo t('Phone Number'); ?></label>
                            <input type="text" name="phone" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><?php echo t('CVR Number'); ?></label>
                            <input type="text" name="cvr" class="form-control">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('Address'); ?></label>
                        <textarea name="address" class="form-control" rows="2"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('Password'); ?> *</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('Extra Information (Notes)'); ?></label>
                        <textarea name="notes" class="form-control" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-success"><?php echo t('Create Customer'); ?></button>
                    <a href="all_tickets.php" class="btn btn-secondary"><?php echo t('Back to Dashboard'); ?></a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>