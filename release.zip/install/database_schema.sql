-- Database Schema for ConsoleRepair System
-- Includes Users, Tickets, Comments, Brands, Models

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    cvr VARCHAR(20),
    notes TEXT,
    role ENUM('admin', 'customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Brands Table
CREATE TABLE IF NOT EXISTS brands (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
);

-- Seed Brands
INSERT IGNORE INTO brands (name) VALUES 
('Apple'), ('Microsoft'), ('SONY'), ('Nintendo'), 
('Acer'), ('Asus'), ('Lenovo'), ('HP'), ('Dell');

-- 3. Models Table
CREATE TABLE IF NOT EXISTS models (
    id INT AUTO_INCREMENT PRIMARY KEY,
    brand_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    FOREIGN KEY (brand_id) REFERENCES brands(id) ON DELETE CASCADE
);

-- Seed Models
INSERT IGNORE INTO models (brand_id, name) VALUES 
((SELECT id FROM brands WHERE name='Apple'), 'Macbook'),
((SELECT id FROM brands WHERE name='Apple'), 'iMac'),
((SELECT id FROM brands WHERE name='Apple'), 'Mac mini'),
((SELECT id FROM brands WHERE name='Microsoft'), 'Xbox Series X'),
((SELECT id FROM brands WHERE name='Microsoft'), 'Xbox Series S'),
((SELECT id FROM brands WHERE name='Microsoft'), 'Xbox One X'),
((SELECT id FROM brands WHERE name='Microsoft'), 'Xbox One S'),
((SELECT id FROM brands WHERE name='Microsoft'), 'Xbox One'),
((SELECT id FROM brands WHERE name='SONY'), 'Playstation 5'),
((SELECT id FROM brands WHERE name='SONY'), 'Playstation 4 Pro'),
((SELECT id FROM brands WHERE name='SONY'), 'Playstation 4 Slim'),
((SELECT id FROM brands WHERE name='SONY'), 'Playstation 4'),
((SELECT id FROM brands WHERE name='Nintendo'), 'Nintendo Switch OLED'),
((SELECT id FROM brands WHERE name='Nintendo'), 'Nintendo Switch'),
((SELECT id FROM brands WHERE name='Nintendo'), 'Nintendo Switch Lite');

-- 4. Tickets Table
CREATE TABLE IF NOT EXISTS tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    device_serial VARCHAR(100) NOT NULL,
    brand VARCHAR(50),
    model VARCHAR(100),
    device_password VARCHAR(100),
    fault_description TEXT NOT NULL,
    status ENUM('Waiting to Arrive', 'Under Repair', 'Waiting for parts', 'Repaired', 'Canceled', 'Shipped', 'RMA') DEFAULT 'Waiting to Arrive',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 5. Comments Table
CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    user_id INT NOT NULL,
    comment TEXT NOT NULL,
    is_private TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 6. Languages Table
CREATE TABLE IF NOT EXISTS languages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(10) NOT NULL UNIQUE,
    name VARCHAR(50) NOT NULL,
    flag_icon VARCHAR(50) DEFAULT 'fa-globe',
    is_active TINYINT(1) DEFAULT 1,
    is_default TINYINT(1) DEFAULT 0
);

-- Seed Default Language
INSERT IGNORE INTO languages (code, name, is_active, is_default) VALUES ('en', 'English', 1, 1);

-- 7. Translations Table
CREATE TABLE IF NOT EXISTS translations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    language_id INT NOT NULL,
    translation_key VARCHAR(255) NOT NULL,
    translation_value TEXT,
    FOREIGN KEY (language_id) REFERENCES languages(id) ON DELETE CASCADE,
    UNIQUE KEY unique_translation (language_id, translation_key)
);
