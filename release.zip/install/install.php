<?php
session_start();
$message = '';
$error = '';

if (file_exists('../config/database.php')) {
    $message = "System appears to be already installed. Please delete config/database.php to reinstall.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['db_host'];
    $db_name = $_POST['db_name'];
    $db_user = $_POST['db_user'];
    $db_pass = $_POST['db_pass'];

    $company_name = $_POST['company_name'];
    $admin_email = $_POST['admin_email'];
    $admin_pass = $_POST['admin_pass'];

    try {
        // Test Database Connection
        $pdo = new PDO("mysql:host=$db_host", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Create Database if not exists
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name`");
        $pdo->exec("USE `$db_name`");

        // Parse and Execute Schema
        $sql = file_get_contents('database_schema.sql');

        // Remove comments
        $lines = explode("\n", $sql);
        $clean_sql = "";
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line && substr($line, 0, 2) !== '--' && substr($line, 0, 1) !== '#') {
                $clean_sql .= $line . "\n";
            }
        }

        // Split by semicolon using regex to avoid splitting inside quotes (basic implementation)
        // For this schema, simple explode is mostly sufficient but let's be cleaner
        $queries = array_filter(array_map('trim', explode(';', $clean_sql)));

        foreach ($queries as $query) {
            if (!empty($query)) {
                $pdo->exec($query);
            }
        }

        // Create Admin User
        $hashed_pass = password_hash($admin_pass, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES ('Admin', ?, ?, 'admin')");
        $stmt->execute([$admin_email, $hashed_pass]);

        // Handle Logo Upload
        if (isset($_FILES['company_logo']) && $_FILES['company_logo']['error'] === 0) {
            $target_dir = "../images/";
            if (!is_dir($target_dir))
                mkdir($target_dir);
            $target_file = $target_dir . "logo.png";
            move_uploaded_file($_FILES['company_logo']['tmp_name'], $target_file);
        }

        // Write Config File
        $config_content = "<?php
\$host = '$db_host';
\$dbname = '$db_name';
\$username = '$db_user';
\$password = '$db_pass';

try {
    \$pdo = new PDO(\"mysql:host=\$host;dbname=\$dbname\", \$username, \$password);
    \$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException \$e) {
    die(\"Could not connect to the database \$dbname :\" . \$e->getMessage());
}
?>";
        file_put_contents('../config/database.php', $config_content);

        // Write Settings File (Simulated by updating a config.php or just writing a settings file)
        // For now, we will create a settings.php to store company name
        $settings_content = "<?php
define('COMPANY_NAME', '" . addslashes($company_name) . "');
?>";
        file_put_contents('../config/settings.php', $settings_content);

        $message = "Installation Successful! Please delete the 'install' folder and <a href='../login.php'>Login here</a>.";

    } catch (PDOException $e) {
        $error = "Database Error: " . $e->getMessage();
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Installation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts: Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .install-card {
            max-width: 600px;
            margin: 50px auto;
        }
    </style>
</head>

<body>
    <div class="card install-card shadow">
        <div class="card-header bg-primary text-white text-center">
            <h3>Installation Wizard</h3>
        </div>
        <div class="card-body">
            <?php if ($message): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php elseif ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if (!$message): ?>
                <form method="POST" enctype="multipart/form-data">
                    <h5 class="mb-3">Database Setup</h5>
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label>DB Host</label>
                            <input type="text" name="db_host" class="form-control" value="localhost" required>
                        </div>
                        <div class="col-md-6">
                            <label>DB Name</label>
                            <input type="text" name="db_name" class="form-control" value="repair_db" required>
                        </div>
                        <div class="col-md-6">
                            <label>DB User</label>
                            <input type="text" name="db_user" class="form-control" value="root" required>
                        </div>
                        <div class="col-md-6">
                            <label>DB Password</label>
                            <input type="password" name="db_pass" class="form-control">
                        </div>
                    </div>

                    <h5 class="mb-3">Company Settings</h5>
                    <div class="mb-3">
                        <label>Company Name</label>
                        <input type="text" name="company_name" class="form-control" placeholder="e.g. ConsoleFix.dk"
                            required>
                    </div>
                    <div class="mb-3">
                        <label>Company Logo</label>
                        <input type="file" name="company_logo" class="form-control" accept="image/png, image/jpeg">
                        <small class="text-muted">Will be saved as logo.png</small>
                    </div>

                    <h5 class="mb-3">Admin Account</h5>
                    <div class="mb-3">
                        <label>Admin Email</label>
                        <input type="email" name="admin_email" class="form-control" placeholder="admin@example.com"
                            required>
                    </div>
                    <div class="mb-3">
                        <label>Admin Password</label>
                        <input type="password" name="admin_pass" class="form-control" required>
                    </div>

                    <button type="submit" class="btn btn-success w-100">Install System</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>