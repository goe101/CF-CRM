<?php
require_once 'includes/init.php';
requireLogin();
requireAdmin();

if (!isset($_GET['id'])) {
    header("Location: languages.php");
    exit;
}

$langId = (int) $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM languages WHERE id = ?");
$stmt->execute([$langId]);
$language = $stmt->fetch();

if (!$language) {
    die("Language not found.");
}

// Handle Save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token']);

    if (isset($_POST['translations']) && is_array($_POST['translations'])) {
        $stmt = $pdo->prepare("INSERT INTO translations (language_id, translation_key, translation_value) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE translation_value = ?");

        foreach ($_POST['translations'] as $key => $value) {
            $key = base64_decode($key); // Decode key
            $value = trim($value);
            if ($value !== '') {
                $stmt->execute([$langId, $key, $value, $value]);
            }
        }
        $success = "Translations saved successfully.";
    }
}

// Fetch Existing Translations
$stmt = $pdo->prepare("SELECT translation_key, translation_value FROM translations WHERE language_id = ?");
$stmt->execute([$langId]);
$existingTranslations = [];
while ($row = $stmt->fetch()) {
    $existingTranslations[$row['translation_key']] = $row['translation_value'];
}

// Defacto Keys (Scan code or Manual List)
$keys = [
    // General / Actions
    'Login to Start', 'Go to Dashboard', 'Login', 'Logout', 'Sign In',
    'Submit Ticket', 'Cancel', 'Search', 'Details', 'Save Translations',
    'Add Language', 'Set Default', 'Edit Translations', 'Delete', 'Back to Languages',
    'View', 'Edit', 'Export', 'Back', 'Print Ticket', 'Update Status', 'Post Comment',
    'Create Customer', 'Back to Dashboard', 'Update Profile', 'Menu',
    
    // Headers / Titles
    'Repair Services', 'Track Your Repairs', 'Expert Technicians',
    'Overview', 'Manage Tickets', 'Devices', 'Customers', 'Languages',
    'My Tickets', 'New Ticket', 'New Customer', 'Profile', 'Open New Ticket',
    'Create New Ticket (Admin)', 'Manage Languages', 'Edit Translations',
    'Manage All Tickets', 'Device Management', 'All Tickets', 'Ticket #',
    'Create New Customer', 'Brands', 'Models', 'Comments/Updates',
    
    // Form Labels & Placeholders
    'Email Address', 'Password', 'Customer', 'Select Customer', 'Brand', 'Select Brand',
    'Model', 'Enter Model Name', 'Device Serial Number', 'Device Login Code / PIN',
    'e.g. 1234 or Pattern', 'Fault Description', 'Search by Ticket ID, Device, Serial, Status...',
    'Language Name', 'Language Code (ISO)', 'e.g., Danish', 'e.g., da',
    'Search by Customer, Device, Serial, Status...', 'Search by Ticket ID, Customer, Serial, Model...',
    'Search by Name, Email, or Phone...', 'Full Name', 'Phone', 'Phone Number', 'Address', 'CVR', 'CVR Number',
    'Extra Information (Notes)', 'New Password (leave blank to keep current)', 'Add Comment',
    'Private (Internal Only)', 'New Brand Name', 'New Model Name', 'Select Brand', 'Add',
    
    // Table Headers
    'ID', 'Date', 'Status', 'Action', 'Created', 'Device Info', 'Serial',
    'Name', 'Code', 'Default', 'Role', 'Email',
    
    // Messages / Descriptions
    'Specializing in Laptop Motherboard and Gaming Consoles Repairs.',
    'Log in to view the real-time status of your device. We provide detailed updates.',
    'We handle complex motherboard repairs for Apple, Sony, Microsoft, and more.',
    'Invalid email or password.', 'Please fill in all fields.', 'Error creating ticket.', 'All fields are required.',
    'You have no tickets yet.', 'No data available.', 'No tickets found.', 'No customers found.',
    'No comments yet.', 'Ticket not found.', 'Access Denied.', 'Brand added successfully.',
    'Model added successfully.', 'Customer created successfully!', 'Profile updated successfully!',
    'Email cannot be changed.', 'Not Provided', 'N/A', 'Private',
    'All rights reserved.', 'System Version',
    
    // Stats / Overview
    'Total Tickets', 'Open Repairs', 'Repaired', 'Ticket Status Breakdown', 'Top Brands',
    
    // Statuses
    'All Statuses',
    'Waiting to Arrive', 'Under Repair', 'Waiting for parts', 'Canceled', 'Shipped','Repaired', 'RMA'
];

// Merge with keys already in DB for this language (in case we missed some in the hardcoded list)
$keys = array_unique(array_merge($keys, array_keys($existingTranslations)));
sort($keys);

include 'includes/nav.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Edit Translations: <span class="text-primary"><?php echo e($language['name']); ?></span></h2>
        <a href="languages.php" class="btn btn-secondary">Back to Languages</a>
    </div>

    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST">
                <?php echo csrfInput(); ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 40%;">Source Text (English/Key)</th>
                                <th>Translation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($keys as $key): ?>
                                <tr>
                                    <td><?php echo e($key); ?></td>
                                    <td>
                                        <!-- Base64 encode key to handle special chars in name attribute -->
                                        <input type="text" class="form-control"
                                            name="translations[<?php echo base64_encode($key); ?>]"
                                            value="<?php echo e($existingTranslations[$key] ?? ''); ?>"
                                            placeholder="Enter translation...">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save Translations</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>