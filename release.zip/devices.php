<?php
/**
 * Device Management (Admin Only)
 * 
 * CRUD interface for Brands and Models.
 * Populates the dropdowns used in Ticket Creation.
 */
require_once 'includes/init.php';

requireAdmin();

$message = '';
$error = '';

// Handle Brand Deletion
if (isset($_GET['delete_brand'])) {
    verifyCsrfToken($_GET['csrf_token'] ?? '');
    $id = $_GET['delete_brand'];
    $stmt = $pdo->prepare("DELETE FROM brands WHERE id = ?");
    if ($stmt->execute([$id])) {
        $message = "Brand deleted successfully.";
    } else {
        $error = "Error deleting brand.";
    }
}

// Handle Model Deletion
if (isset($_GET['delete_model'])) {
    verifyCsrfToken($_GET['csrf_token'] ?? '');
    $id = $_GET['delete_model'];
    $stmt = $pdo->prepare("DELETE FROM models WHERE id = ?");
    if ($stmt->execute([$id])) {
        $message = "Model deleted successfully.";
    } else {
        $error = "Error deleting model.";
    }
}

// Handle Add Brand
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_brand'])) {
    verifyCsrfToken($_POST['csrf_token']);
    $brand_name = trim($_POST['brand_name']);
    if ($brand_name) {
        $stmt = $pdo->prepare("INSERT INTO brands (name) VALUES (?)");
        if ($stmt->execute([$brand_name])) {
            $message = "Brand added successfully.";
        } else {
            $error = "Error adding brand (might already exist).";
        }
    }
}

// Handle Add Model
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_model'])) {
    verifyCsrfToken($_POST['csrf_token']);
    $model_name = trim($_POST['model_name']);
    $brand_id = $_POST['brand_id'];
    if ($model_name && $brand_id) {
        $stmt = $pdo->prepare("INSERT INTO models (brand_id, name) VALUES (?, ?)");
        if ($stmt->execute([$brand_id, $model_name])) {
            $message = "Model added successfully.";
        } else {
            $error = "Error adding model.";
        }
    }
}

// Fetch Brands and Models
$brands = $pdo->query("SELECT * FROM brands ORDER BY name ASC")->fetchAll();
$models = $pdo->query("SELECT m.*, b.name as brand_name FROM models m JOIN brands b ON m.brand_id = b.id ORDER BY b.name ASC, m.name ASC")->fetchAll();

include 'includes/nav.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?php echo t('Device Management'); ?></h2>
</div>

<?php if ($message): ?>
    <div class="alert alert-success"><?php echo $message; ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="row">
    <!-- Brands Column -->
    <div class="col-md-5">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><?php echo t('Brands'); ?></h5>
            </div>
            <div class="card-body">
                <form method="POST" class="mb-3 d-flex">
                    <?php echo csrfInput(); ?>
                    <input type="text" name="brand_name" class="form-control me-2"
                        placeholder="<?php echo t('New Brand Name'); ?>" required>
                    <button type="submit" name="add_brand" class="btn btn-primary"><?php echo t('Add'); ?></button>
                </form>
                <div class="list-group">
                    <?php foreach ($brands as $brand): ?>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <?php echo htmlspecialchars($brand['name']); ?>
                            <a href="devices.php?delete_brand=<?php echo $brand['id']; ?>&csrf_token=<?php echo generateCsrfToken(); ?>"
                                class="btn btn-sm btn-danger"
                                onclick="return confirm('Delete this brand and all its models?')">&times;</a>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Models Column -->
    <div class="col-md-7">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0"><?php echo t('Models'); ?></h5>
            </div>
            <div class="card-body">
                <form method="POST" class="mb-3">
                    <?php echo csrfInput(); ?>
                    <div class="row g-2">
                        <div class="col-md-5">
                            <select name="brand_id" class="form-select" required>
                                <option value=""><?php echo t('Select Brand'); ?></option>
                                <?php foreach ($brands as $brand): ?>
                                    <option value="<?php echo $brand['id']; ?>">
                                        <?php echo htmlspecialchars($brand['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-5">
                            <input type="text" name="model_name" class="form-control"
                                placeholder="<?php echo t('New Model Name'); ?>" required>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" name="add_model"
                                class="btn btn-primary w-100"><?php echo t('Add'); ?></button>
                        </div>
                    </div>
                </form>
                <div class="table-responsive" style="max-height: 500px; overflow-y: auto;">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th><?php echo t('Brand'); ?></th>
                                <th><?php echo t('Model'); ?></th>
                                <th><?php echo t('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($models as $model): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($model['brand_name']); ?></td>
                                    <td><?php echo htmlspecialchars($model['name']); ?></td>
                                    <td>
                                        <a href="devices.php?delete_model=<?php echo $model['id']; ?>&csrf_token=<?php echo generateCsrfToken(); ?>"
                                            class="text-danger" onclick="return confirm('Delete this model?')"><i
                                                class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>