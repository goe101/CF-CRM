<?php
/**
 * Ticket Details Controller
 * 
 * Handles viewing specific ticket details, updating status (Admin only),
 * and posting comments (Admin & Customer).
 */
require_once 'includes/init.php';
requireLogin();

if (!isset($_GET['id'])) {
    header("Location: all_tickets.php");
    exit;
}

// ... (Fetch logic remains the same, I will use ReplaceChunk to just target the top and the POST check)
// Actually, I can replace the top block and then the POST block separately.

// BLOCK 1: Top Include
// BLOCK 2: POST Check


$ticket_id = $_GET['id'];
$user_id = $_SESSION['user_id'];
$is_admin = isAdmin();

// Fetch Ticket
$stmt = $pdo->prepare("SELECT t.*, u.name as customer_name, u.phone, u.email
FROM tickets t
JOIN users u ON t.customer_id = u.id
WHERE t.id = ?");
$stmt->execute([$ticket_id]);
$ticket = $stmt->fetch();

if (!$ticket) {
    die("Ticket not found.");
}

// Access Control: Admin or Ticket Owner
if (!$is_admin && $ticket['customer_id'] != $user_id) {
    die("Access Denied.");
}

// Handle Forms
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update Status (Admin Only)
    if ($is_admin && isset($_POST['update_status'])) {
        $new_status = $_POST['status'];
        $stmt = $pdo->prepare("UPDATE tickets SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $ticket_id]);
        $ticket['status'] = $new_status; // Reflect change
    }

    // Add Comment
    if (isset($_POST['add_comment'])) {
        $comment = trim($_POST['comment']);
        $is_private = isset($_POST['is_private']) ? 1 : 0;

        if ($comment) {
            $stmt = $pdo->prepare("INSERT INTO comments (ticket_id, user_id, comment, is_private) VALUES (?, ?, ?, ?)");
            $stmt->execute([$ticket_id, $user_id, $comment, $is_private]);
        }
    }
}

// Fetch Comments
$sql = "SELECT c.*, u.name as user_name, u.role as user_role
FROM comments c
JOIN users u ON c.user_id = u.id
WHERE c.ticket_id = ? ";

if (!$is_admin) {
    $sql .= " AND c.is_private = 0 ";
}

$sql .= " ORDER BY c.created_at ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$ticket_id]);
$comments = $stmt->fetchAll();

include 'includes/nav.php';
?>

<div class="row noprint">
    <div class="col-md-12 mb-3">
        <a href="<?php echo $is_admin ? 'all_tickets.php' : 'my_tickets.php'; ?>" class="btn btn-secondary">&laquo;
            <?php echo t('Back'); ?></a>
        <button onclick="window.print()" class="btn btn-warning float-end"><?php echo t('Print Ticket'); ?></button>
    </div>
</div>

<div class="row">
    <!-- Print Header -->
    <div class="col-12 text-center d-none d-print-block mb-4">
        <img src="images/logo.png" alt="ConsoleFix.dk" style="max-height: 80px;">
        <h2>ConsoleFix.dk</h2>
    </div>

    <!-- Ticket Details -->
    <div class="col-md-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h4 class="mb-0"><?php echo t('Ticket #'); ?><?php echo $ticket['id']; ?></h4>
                <div class="noprint">
                    <?php echo getStatusBadge(t($ticket['status'])); ?>
                </div>
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <strong><?php echo t('Customer'); ?>:</strong>
                        <?php echo htmlspecialchars($ticket['customer_name']); ?><br>
                        <strong><?php echo t('Email'); ?>:</strong>
                        <?php echo htmlspecialchars($ticket['email']); ?><br>
                        <strong><?php echo t('Phone'); ?>:</strong> <?php echo htmlspecialchars($ticket['phone']); ?>
                    </div>
                    <div class="col-md-6 text-end">
                        <?php echo $ticket['created_at']; ?>
                    </div>
                </div>
                <div class="row mb-3 bg-light p-2 rounded mx-0">
                    <div class="col-md-4">
                        <strong><?php echo t('Brand'); ?>:</strong><br>
                        <?php echo htmlspecialchars($ticket['brand'] ?? t('N/A')); ?>
                    </div>
                    <div class="col-md-4">
                        <strong><?php echo t('Model'); ?>:</strong><br>
                        <?php echo htmlspecialchars($ticket['model'] ?? t('N/A')); ?>
                    </div>
                    <div class="col-md-4">
                        <strong><?php echo t('Device Serial'); ?>:</strong><br>
                        <?php echo htmlspecialchars($ticket['device_serial']); ?>
                    </div>
                </div>
                <div class="row mb-3 bg-light p-2 rounded mx-0">
                    <div class="col-md-12">
                        <strong><?php echo t('Login Code/PIN'); ?>:</strong>
                        <span
                            class="fs-5 fw-bold text-danger ms-2"><?php echo htmlspecialchars($ticket['device_password'] ?? t('Not Provided')); ?></span>
                    </div>
                </div>
                <hr>
                <h5><?php echo t('Fault Description'); ?>:</h5>
                <p class="p-3 rounded border"><?php echo nl2br(htmlspecialchars($ticket['fault_description'])); ?></p>
            </div>
        </div>

        <!-- Comments Section -->
        <div class="card shadow-sm">
            <div class="card-header">
                <h5><?php echo t('Comments/Updates'); ?></h5>
            </div>
            <div class="card-body">
                <?php foreach ($comments as $comment): ?>
                    <div
                        class="mb-3 border-bottom pb-2 <?php echo $comment['is_private'] ? 'bg-warning bg-opacity-10 p-2 rounded noprint' : ''; ?>">
                        <div class="d-flex justify-content-between">
                            <strong>
                                <?php echo htmlspecialchars($comment['user_name']); ?>
                                <span class="badge bg-secondary"><?php echo ucfirst($comment['user_role']); ?></span>
                                <?php if ($comment['is_private']): ?> <span
                                        class="badge bg-danger"><?php echo t('Private'); ?></span><?php endif; ?>
                            </strong>
                            <small class="text-muted"><?php echo $comment['created_at']; ?></small>
                        </div>
                        <p class="mt-1 mb-0"><?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
                    </div>
                <?php endforeach; ?>

                <?php if (count($comments) === 0): ?>
                    <p class="text-muted text-center"><?php echo t('No comments yet.'); ?></p>
                <?php endif; ?>

                <div class="noprint mt-4">
                    <form method="POST">
                        <?php echo csrfInput(); ?>
                        <div class="mb-2">
                            <label class="form-label"><?php echo t('Add Comment'); ?></label>
                            <textarea name="comment" class="form-control" rows="3" required></textarea>
                        </div>
                        <?php if ($is_admin): ?>
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" name="is_private" id="privateCheck">
                                <label class="form-check-label"
                                    for="privateCheck"><?php echo t('Private (Internal Only)'); ?></label>
                            </div>
                        <?php endif; ?>
                        <button type="submit" name="add_comment"
                            class="btn btn-primary btn-sm"><?php echo t('Post Comment'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar / Actions (Admin Only) -->
    <div class="col-md-4 noprint">
        <?php if ($is_admin): ?>
            <div class="card shadow-sm mb-3">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><?php echo t('Update Status'); ?></h5>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <?php echo csrfInput(); ?>
                        <select name="status" class="form-select mb-3">
                            <?php
                            $statuses = ['Waiting to Arrive', 'Under Repair', 'Waiting for parts', 'Repaired', 'Canceled', 'Shipped', 'RMA'];
                            foreach ($statuses as $s): ?>
                                <option value="<?php echo $s; ?>" <?php echo $ticket['status'] === $s ? 'selected' : ''; ?>>
                                    <?php echo t($s); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" name="update_status" class="btn btn-primary w-100"><?php echo t('Update Status'); ?></button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Print Styles -->
<style>
    @media print {
        .noprint {
            display: none !important;
        }

        .card {
            border: none !important;
            box-shadow: none !important;
        }

        .card-header {
            background-color: white !important;
            color: black !important;
            border-bottom: 2px solid black !important;
        }

        .badge {
            border: 1px solid black;
            color: black;
        }

        body {
            background-color: white;
        }
    }
</style>

<?php include 'includes/footer.php'; ?>