<?php
/**
 * All Tickets Page (Admin)
 * 
 * Displays a searchable, filterable list of all repair tickets in the system.
 * Allows admins to view status, customer, and device details at a glance.
 */
require_once 'includes/init.php';

requireAdmin();

// Fetch tickets with customer names
// Order by created_at DESC
// Search Logic
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? '';

$sql = "SELECT t.*, u.name as customer_name 
        FROM tickets t 
        LEFT JOIN users u ON t.customer_id = u.id 
        WHERE 1=1";

$params = [];

if ($search) {
    $sql .= " AND (t.id = ? OR u.name LIKE ? OR t.device_serial LIKE ? OR t.model LIKE ?)";
    $params[] = $search;
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($status_filter) {
    $sql .= " AND t.status = ?";
    $params[] = $status_filter;
}

$sql .= " ORDER BY t.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tickets = $stmt->fetchAll();

include 'includes/nav.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?php echo t('All Tickets'); ?></h2>
    <div>
        <a href="create_ticket.php" class="btn btn-primary">+ <?php echo t('New Ticket'); ?></a>
        <a href="create_customer.php" class="btn btn-success">+ <?php echo t('New Customer'); ?></a>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-6">
                <input type="text" name="search" class="form-control"
                    placeholder="<?php echo t('Search by Ticket ID, Customer, Serial, Model...'); ?>"
                    value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-4">
                <select name="status" class="form-select">
                    <option value=""><?php echo t('All Statuses'); ?></option>
                    <?php
                    $statuses = ['Waiting to Arrive', 'Under Repair', 'Waiting for parts', 'Repaired', 'Canceled', 'Shipped', 'RMA'];
                    foreach ($statuses as $s): ?>
                        <option value="<?php echo $s; ?>" <?php echo $status_filter === $s ? 'selected' : ''; ?>>
                            <?php echo t($s); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100"><?php echo t('Search'); ?></button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header">
        <h4 class="mb-0"><?php echo t('All Tickets'); ?></h4>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo t('Customer'); ?></th>
                        <th><?php echo t('Device'); ?></th>
                        <th><?php echo t('Serial'); ?></th>
                        <th><?php echo t('Status'); ?></th>
                        <th><?php echo t('Action'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($tickets) > 0): ?>
                        <?php foreach ($tickets as $ticket): ?>
                            <tr>
                                <td><?php echo $ticket['id']; ?></td>
                                <td><?php echo htmlspecialchars($ticket['customer_name']); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($ticket['brand'] ?? '') . ' ' . htmlspecialchars($ticket['model'] ?? ''); ?></strong>
                                    <br>
                                    <small
                                        class="text-muted"><?php echo htmlspecialchars(substr($ticket['fault_description'], 0, 30)) . '...'; ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($ticket['device_serial']); ?></td>
                                <td><?php echo getStatusBadge(t($ticket['status'])); ?></td>
                                <td>
                                    <a href="ticket.php?id=<?php echo $ticket['id']; ?>"
                                        class="btn btn-sm btn-info text-white"><?php echo t('View'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-3"><?php echo t('No tickets found.'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>