/**
 * Toggles the sidebar navigation.
 * Adjusts the width of the sidebar and the margin of the main content/footer.
 */
function toggleSidebar() {
    var sidebar = document.getElementById("mySidebar");
    var main = document.getElementById("main");

    // Reference to footer to push it along with main content
    var footer = document.querySelector('footer');

    if (sidebar.style.width === "250px" || sidebar.style.width === "") {
        // Close Sidebar
        sidebar.style.width = "0";
        main.style.marginLeft = "0";
        if (footer) footer.style.marginLeft = "0";
    } else {
        // Open Sidebar
        sidebar.style.width = "250px";
        main.style.marginLeft = "250px";
        if (footer) footer.style.marginLeft = "250px";
    }
}
