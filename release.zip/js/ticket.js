/**
 * Updates the Model input field based on the selected Brand.
 * 
 * If the selected brand has predefined models in `window.modelsData`, it renders a <select>.
 * Otherwise, it renders a text <input> for manual entry.
 * 
 * Logic:
 * - Reads `window.modelsData` (populated via PHP).
 * - Checks if `brandSelect` value exists in data.
 * - Swaps HTML content of `modelContainer`.
 */
function updateModelInput() {
    const models = window.modelsData || {};
    const brand = document.getElementById('brandSelect').value;
    const container = document.getElementById('modelContainer');

    if (models[brand] && models[brand].length > 0) {
        // Create Select Dropdown
        let html = '<select name="model_select" class="form-select" required>';
        html += '<option value="">Select Model</option>';
        models[brand].forEach(m => {
            html += `<option value="${m}">${m}</option>`;
        });
        html += '</select>';
        container.innerHTML = html;
    } else {
        // Create Text Input if no models found (or "Other")
        container.innerHTML = '<input type="text" name="model_input" class="form-control" placeholder="Enter Model Name" required>';
    }
}
