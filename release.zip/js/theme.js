/**
 * Theme Management Logic
 * Handles toggling between light and dark modes and persisting preference.
 */

const getStoredTheme = () => localStorage.getItem('theme');
const setStoredTheme = theme => localStorage.setItem('theme', theme);

const getPreferredTheme = () => {
    const storedTheme = getStoredTheme();
    if (storedTheme) {
        return storedTheme;
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
};

const setTheme = theme => {
    document.documentElement.setAttribute('data-bs-theme', theme);

    // Update Toggle Icon and Text
    const toggleIcon = document.getElementById('theme-icon');
    const toggleText = document.getElementById('theme-text');

    if (toggleIcon) {
        if (theme === 'dark') {
            toggleIcon.classList.remove('fa-sun');
            toggleIcon.classList.add('fa-moon');
            if (toggleText) toggleText.textContent = 'Night Mode';
        } else {
            toggleIcon.classList.remove('fa-moon');
            toggleIcon.classList.add('fa-sun');
            if (toggleText) toggleText.textContent = 'Day Mode';
        }
    }
}

// Toggle Function
const toggleTheme = () => {
    const currentTheme = document.documentElement.getAttribute('data-bs-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setStoredTheme(newTheme);
    setTheme(newTheme);
};

// Initialize Theme on Load
const initTheme = () => {
    const preferredTheme = getStoredTheme() || 'dark'; // Default to dark for this app
    setTheme(preferredTheme);

    // Sync switch state
    const themeSwitch = document.getElementById('themeSwitch');
    if (themeSwitch) {
        themeSwitch.checked = preferredTheme === 'dark'; // Checked = Dark Mode

        // Add listener here to avoid multiple bindings
        themeSwitch.addEventListener('change', () => {
            const newTheme = themeSwitch.checked ? 'dark' : 'light';
            setStoredTheme(newTheme);
            setTheme(newTheme);
        });
    }
};

// Listen for system changes if no override is set
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    if (!getStoredTheme()) {
        setTheme(getPreferredTheme());
    }
});

// Run init immediately to prevet FOUC
initTheme();


