<?php
require_once 'includes/init.php';

requireAdmin();

if (!isset($_GET['id'])) {
    header("Location: customers.php");
    exit;
}

$id = $_GET['id'];
$message = '';
$error = '';

// Fetch User
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'customer'");
$stmt->execute([$id]);
$customer = $stmt->fetch();

if (!$customer) {
    die("Customer not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token']);
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $cvr = trim($_POST['cvr']);
    $notes = trim($_POST['notes']);

    // Password reset if filled
    $password = $_POST['password'];

    if ($name && $email) {
        $sql = "UPDATE users SET name=?, email=?, phone=?, address=?, cvr=?, notes=?";
        $params = [$name, $email, $phone, $address, $cvr, $notes];

        if (!empty($password)) {
            $sql .= ", password=?";
            $params[] = password_hash($password, PASSWORD_DEFAULT);
        }

        $sql .= " WHERE id=?";
        $params[] = $id;

        $stmt = $pdo->prepare($sql);
        if ($stmt->execute($params)) {
            $message = "Customer updated successfully!";
            // Refresh data
            $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$id]);
            $customer = $stmt->fetch();
        } else {
            $error = "Error updating customer.";
        }
    } else {
        $error = "Name and Email are required.";
    }
}

include 'includes/nav.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Edit Customer: <?php echo htmlspecialchars($customer['name']); ?></h4>
                <a href="customers.php" class="btn btn-sm btn-dark">Back to List</a>
            </div>
            <div class="card-body">
                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <form method="POST">
                    <?php echo csrfInput(); ?>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name *</label>
                            <input type="text" name="name" class="form-control"
                                value="<?php echo htmlspecialchars($customer['name']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email Address *</label>
                            <input type="email" name="email" class="form-control"
                                value="<?php echo htmlspecialchars($customer['email']); ?>" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control"
                                value="<?php echo htmlspecialchars($customer['phone']); ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">CVR Number</label>
                            <input type="text" name="cvr" class="form-control"
                                value="<?php echo htmlspecialchars($customer['cvr']); ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Address</label>
                        <textarea name="address" class="form-control"
                            rows="2"><?php echo htmlspecialchars($customer['address']); ?></textarea>
                    </div>

                    <hr>
                    <div class="mb-3">
                        <label class="form-label text-danger">Reset Password (leave blank to keep current)</label>
                        <input type="password" name="password" class="form-control" placeholder="New Password">
                    </div>
                    <hr>

                    <div class="mb-3">
                        <label class="form-label">Extra Information (Notes)</label>
                        <textarea name="notes" class="form-control"
                            rows="3"><?php echo htmlspecialchars($customer['notes']); ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                    <a href="customers.php" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>