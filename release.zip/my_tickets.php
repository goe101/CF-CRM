<?php
require_once 'includes/init.php';

requireLogin();

// If admin accidentally lands here, redirect or just show their tickets (but admins usually use all_tickets.php)
// The spec says "Customer Dashboard", so strictly for customers.
// However, if an admin logs in, they might want to see tickets assigned to them if they were a customer? 
// No, Admins manage all tickets.

$user_id = $_SESSION['user_id'];
$search = $_GET['search'] ?? '';

$sql = "SELECT * FROM tickets WHERE customer_id = ?";
$params = [$user_id];

if ($search) {
    $sql .= " AND (id = ? OR brand LIKE ? OR model LIKE ? OR device_serial LIKE ? OR status LIKE ?)";
    $params[] = $search;
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tickets = $stmt->fetchAll();

include 'includes/nav.php';
?>

<h2 class="mb-4"><?php echo t('My Tickets'); ?></h2>

<!-- Search Form -->
<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-9">
                <input type="text" name="search" class="form-control"
                    placeholder="<?php echo t('Search by Ticket ID, Device, Serial, Status...'); ?>"
                    value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100"><?php echo t('Search'); ?></button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th><?php echo t('Ticket #'); ?></th>
                        <th><?php echo t('Device'); ?></th>
                        <th><?php echo t('Date Submitted'); ?></th>
                        <th><?php echo t('Status'); ?></th>
                        <th><?php echo t('Action'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($tickets) > 0): ?>
                        <?php foreach ($tickets as $ticket): ?>
                            <tr>
                                <td><?php echo $ticket['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($ticket['brand'] ?? '') . ' ' . htmlspecialchars($ticket['model'] ?? ''); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo htmlspecialchars($ticket['device_serial']); ?></small>
                                </td>
                                <td><?php echo date('Y-m-d', strtotime($ticket['created_at'])); ?></td>
                                <td><?php echo getStatusBadge(t($ticket['status'])); ?></td>
                                <td>
                                    <a href="ticket.php?id=<?php echo $ticket['id']; ?>"
                                        class="btn btn-sm btn-primary"><?php echo t('Details'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-3"><?php echo t('You have no tickets yet.'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>