<?php
/**
 * Customer Management (Admin Only)
 * 
 * detailed list of customers with search functionality.
 * Links to Create and Edit customer pages.
 */
require_once 'includes/init.php';

requireAdmin();

$search = $_GET['search'] ?? '';

$sql = "SELECT * FROM users WHERE role = 'customer' AND 1=1";
$params = [];

if ($search) {
    $sql .= " AND (name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY name ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$customers = $stmt->fetchAll();

include 'includes/nav.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?php echo t('Customers'); ?></h2>
    <a href="create_customer.php" class="btn btn-success">+ <?php echo t('New Customer'); ?></a>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-10">
                <input type="text" name="search" class="form-control"
                    placeholder="<?php echo t('Search by Name, Email, or Phone...'); ?>"
                    value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100"><?php echo t('Search'); ?></button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th><?php echo t('ID'); ?></th>
                        <th><?php echo t('Name'); ?></th>
                        <th><?php echo t('Email'); ?></th>
                        <th><?php echo t('Phone'); ?></th>
                        <th><?php echo t('CVR'); ?></th>
                        <th><?php echo t('Actions'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($customers) > 0): ?>
                        <?php foreach ($customers as $customer): ?>
                            <tr>
                                <td><?php echo $customer['id']; ?></td>
                                <td><?php echo htmlspecialchars($customer['name']); ?></td>
                                <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                <td><?php echo htmlspecialchars($customer['phone']); ?></td>
                                <td><?php echo htmlspecialchars($customer['cvr']); ?></td>
                                <td>
                                    <a href="edit_customer.php?id=<?php echo $customer['id']; ?>"
                                        class="btn btn-sm btn-primary"><?php echo t('Edit'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-3"><?php echo t('No customers found.'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>