<?php
require_once 'includes/init.php';

requireLogin();

$user_id = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $password = $_POST['password'];

    $sql = "UPDATE users SET name = ?, phone = ?, address = ?";
    $params = [$name, $phone, $address];

    if (!empty($password)) {
        $sql .= ", password = ?";
        $params[] = password_hash($password, PASSWORD_DEFAULT);
    }

    $sql .= " WHERE id = ?";
    $params[] = $user_id;

    $stmt = $pdo->prepare($sql);
    if ($stmt->execute($params)) {
        $_SESSION['name'] = $name; // Update session name
        $message = "Profile updated successfully!";
    } else {
        $message = "Error updating profile.";
    }
}

// Fetch current data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

include 'includes/nav.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-header bg-info text-white">
                <h4 class="mb-0"><?php echo t('Profile'); ?></h4>
            </div>
            <div class="card-body">
                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars(t($message)); ?></div>
                <?php endif; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('Full Name'); ?></label>
                        <input type="text" name="name" class="form-control"
                            value="<?php echo htmlspecialchars($user['name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('Email'); ?></label>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>"
                            disabled>
                        <small class="text-muted"><?php echo t('Email cannot be changed.'); ?></small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('Phone'); ?></label>
                        <input type="text" name="phone" class="form-control"
                            value="<?php echo htmlspecialchars($user['phone']); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('Address'); ?></label>
                        <textarea name="address" class="form-control"
                            rows="2"><?php echo htmlspecialchars($user['address']); ?></textarea>
                    </div>
                    <hr>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('New Password (leave blank to keep current)'); ?></label>
                        <input type="password" name="password" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-info text-white"><?php echo t('Update Profile'); ?></button>
                    <a href="javascript:history.back()" class="btn btn-secondary"><?php echo t('Back'); ?></a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>