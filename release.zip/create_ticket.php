<?php
/**
 * Create Ticket Logic
 * 
 * Handles the creation of new repair tickets.
 * - Admin: Can select existing customers.
 * - Customer: Creates ticket for themselves.
 * - Dynamic Brand/Model selection via JS.
 */
require_once 'includes/init.php';

requireLogin(); // Now allows both Admin and Customer

$message = '';
$error = '';
$is_admin = isAdmin();

// Fetch customers for dropdown (Admin Only)
$customers = [];
if ($is_admin) {
    $customers = $pdo->query("SELECT id, name, email FROM users WHERE role = 'customer' ORDER BY name ASC")->fetchAll();
}
// Fetch brands for dropdown
$brands = $pdo->query("SELECT * FROM brands ORDER BY name ASC")->fetchAll();

// Fetch all models as JSON for JS
$models_stmt = $pdo->query("SELECT m.name, b.name as brand_name FROM models m JOIN brands b ON m.brand_id = b.id ORDER
BY m.name ASC");
$all_models = $models_stmt->fetchAll(PDO::FETCH_ASSOC);

// Group models by brand for easier JS consumption
$models_by_brand = [];
foreach ($all_models as $m) {
    $models_by_brand[$m['brand_name']][] = $m['name'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // If admin, get chosen customer. If customer, use own ID.
    $customer_id = $is_admin ? $_POST['customer_id'] : $_SESSION['user_id'];

    $brand = $_POST['brand'];
    // Model logic: if brand has dropdown, use that, else use text input
    $model_select = $_POST['model_select'] ?? '';
    $model_text = trim($_POST['model_input'] ?? '');

    // Determine which model field to use based on brand
    $model = '';
    // Determine which model field to use based on brand - Re-query to check if brand has models
    $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM models m JOIN brands b ON m.brand_id = b.id WHERE b.name = ?");
    $stmt_check->execute([$brand]);
    $has_models = $stmt_check->fetchColumn() > 0;

    $model = '';
    if ($has_models) {
        $model = $model_select;
    } else {
        $model = $model_text;
    }

    $device_serial = trim($_POST['device_serial']);
    $device_password = trim($_POST['device_password']);
    $fault_description = trim($_POST['fault_description']);

    if ($customer_id && $brand && $model && $device_serial && $fault_description) {
        $stmt = $pdo->prepare("INSERT INTO tickets (customer_id, brand, model, device_serial, device_password,
fault_description) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$customer_id, $brand, $model, $device_serial, $device_password, $fault_description])) {
            $new_ticket_id = $pdo->lastInsertId();
            // Redirect based on role
            if ($is_admin) {
                header("Location: ticket.php?id=" . $new_ticket_id);
            } else {
                header("Location: my_tickets.php");
            }
            exit;
        } else {
            $error = "Error creating ticket.";
        }
    } else {
        $error = "All fields are required.";
    }
}

include 'includes/nav.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">
                    <?php echo htmlspecialchars($is_admin ? t('Create New Ticket (Admin)') : t('Open New Ticket')); ?>
                </h4>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars(t($error)); ?></div>
                <?php endif; ?>

                <form method="POST" id="ticketForm">
                    <?php echo csrfInput(); ?>
                    <?php if ($is_admin): ?>
                        <div class="mb-3">
                            <label class="form-label"><?php echo t('Customer'); ?> *</label>
                            <select name="customer_id" class="form-select" required>
                                <option value=""><?php echo t('Select Customer'); ?></option>
                                <?php foreach ($customers as $customer): ?>
                                    <option value="<?php echo $customer['id']; ?>">
                                        <?php echo htmlspecialchars($customer['name'] . ' (' . $customer['email'] . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php endif; ?>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label"><?php echo t('Brand'); ?> *</label>
                            <select name="brand" id="brandSelect" class="form-select" required
                                onchange="updateModelInput()">
                                <option value=""><?php echo t('Select Brand'); ?></option>
                                <?php foreach ($brands as $brand): ?>
                                    <option value="<?php echo htmlspecialchars($brand['name']); ?>">
                                        <?php echo htmlspecialchars($brand['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><?php echo t('Model'); ?> *</label>
                            <!-- Dynamic Inputs -->
                            <div id="modelContainer">
                                <input type="text" name="model_input" class="form-control"
                                    placeholder="<?php echo t('Enter Model Name'); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label"><?php echo t('Device Serial Number'); ?> *</label>
                            <input type="text" name="device_serial" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label"><?php echo t('Device Login Code / PIN'); ?></label>
                            <input type="text" name="device_password" class="form-control"
                                placeholder="<?php echo t('e.g. 1234 or Pattern'); ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label"><?php echo t('Fault Description'); ?> *</label>
                        <textarea name="fault_description" class="form-control" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo t('Submit Ticket'); ?></button>
                    <a href="<?php echo $is_admin ? 'all_tickets.php' : 'my_tickets.php'; ?>"
                        class="btn btn-secondary"><?php echo t('Cancel'); ?></a>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
    window.modelsData = <?php echo json_encode($models_by_brand); ?>;
</script>
<script src="js/ticket.js"></script>

<?php include 'includes/footer.php'; ?>