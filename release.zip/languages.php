<?php
require_once 'includes/init.php';
requireLogin();
requireAdmin();

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken($_POST['csrf_token']);

    if (isset($_POST['add_language'])) {
        $name = trim($_POST['name']);
        $code = trim($_POST['code']);

        if ($name && $code) {
            try {
                $stmt = $pdo->prepare("INSERT INTO languages (name, code) VALUES (?, ?)");
                $stmt->execute([$name, $code]);
                $success = "Language added successfully.";
            } catch (PDOException $e) {
                if ($e->getCode() == 23000) {
                    $error = "Language code already exists.";
                } else {
                    $error = "Error adding language: " . $e->getMessage();
                }
            }
        } else {
            $error = "Name and Code are required.";
        }
    }

    if (isset($_POST['set_default'])) {
        $langId = (int) $_POST['default_lang_id'];
        if (set_default_language($langId)) {
            $success = "Default language updated.";
        } else {
            $error = "Failed to update default language.";
        }
    }

    if (isset($_POST['delete_language'])) {
        $langId = (int) $_POST['delete_lang_id'];

        // Prevent deleting the default language
        $stmt = $pdo->prepare("SELECT is_default FROM languages WHERE id = ?");
        $stmt->execute([$langId]);
        $isDefault = $stmt->fetchColumn();

        if ($isDefault) {
            $error = "Cannot delete the default language.";
        } else {
            // Delete with Transaction
            try {
                $pdo->beginTransaction();

                // 1. Delete associated translations first (to avoid FK constraint failure)
                $stmt = $pdo->prepare("DELETE FROM translations WHERE language_id = ?");
                $stmt->execute([$langId]);

                // 2. Delete the language itself
                $stmt = $pdo->prepare("DELETE FROM languages WHERE id = ?");
                $stmt->execute([$langId]);

                $pdo->commit();
                $success = "Language deleted successfully.";
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                // Check for specific integrity constraint violation
                if ($e->getCode() == 23000) {
                    $error = "Cannot delete language: It is currently in use by other records.";
                } else {
                    $error = "Error deleting language: " . $e->getMessage();
                }
            }
        }
    }
}

// Fetch Languages
$stmt = $pdo->query("SELECT * FROM languages ORDER BY name ASC");
$languages = $stmt->fetchAll();

include 'includes/nav.php';
?>

<div class="container py-4">
    <div class="row mb-4">
        <div class="col">
            <h2><?php echo t('Manage Languages'); ?></h2>
        </div>
        <div class="col-auto">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addLanguageModal">
                <i class="fas fa-plus"></i> <?php echo t('Add Language'); ?>
            </button>
        </div>
    </div>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>
    <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Status</th>
                        <th>Default</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($languages as $lang): ?>
                        <tr>
                            <td><?php echo $lang['id']; ?></td>
                            <td><?php echo e($lang['name']); ?></td>
                            <td><span class="badge bg-secondary"><?php echo e($lang['code']); ?></span></td>
                            <td>
                                <?php if ($lang['is_active']): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($lang['is_default']): ?>
                                    <span class="badge bg-info text-dark">Default</span>
                                <?php else: ?>
                                    <form method="POST" class="d-inline">
                                        <?php echo csrfInput(); ?>
                                        <input type="hidden" name="set_default" value="1">
                                        <input type="hidden" name="default_lang_id" value="<?php echo $lang['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-secondary">Set Default</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="edit_language.php?id=<?php echo $lang['id']; ?>"
                                    class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i> Edit Translations
                                </a>
                                <?php if (!$lang['is_default']): ?>
                                    <form method="POST" class="d-inline"
                                        onsubmit="return confirm('Are you sure? This will delete all translations for this language.');">
                                        <?php echo csrfInput(); ?>
                                        <input type="hidden" name="delete_language" value="1">
                                        <input type="hidden" name="delete_lang_id" value="<?php echo $lang['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-outline-danger disabled" disabled>Delete</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Language Modal -->
<div class="modal fade" id="addLanguageModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Language</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <?php echo csrfInput(); ?>
                    <input type="hidden" name="add_language" value="1">
                    <div class="mb-3">
                        <label class="form-label">Language Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g., Danish" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Language Code (ISO)</label>
                        <input type="text" name="code" class="form-control" placeholder="e.g., da" maxlength="10"
                            required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Language</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>